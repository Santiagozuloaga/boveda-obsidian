<!-- E-100 V2 | datos verificados vía Notion REST API el 2026-10-04 | fuente: 90 SISTEMA/E100_V2/ | sin datos inventados -->

# E100_ECOSYSTEM_MASTER_PLAN

## 1. Estado real de la trinidad (verificado)
| Herramienta | Rol | Estado | Bloqueo |
|---|---|---|---|
| Obsidian | Cerebro: conocimiento y fuente de verdad | Operativa, con 111 ficheros en staging | 41 sin descorruptar |
| Notion | Centro de operaciones: fechas y estado | Operativa, 6 bases, hoy con 10 correcciones | MCP desactivado en OpenCode |
| Todoist | Arma de corto plazo | **No conectada** | Sin token, MCP desactivado |

**Conclusión: la trinidad no funciona como sistema.** Notion y Obsidian están
vivas pero desconectadas; Todoist no existe como capa.

## 2. Cuellos de botella reales (ordenados por daño)
| # | Cuello | Daño | Coste de arreglo |
|---|---|---|---|
| 1 | Sin `git init` en la bóveda | Un error de escritura es irreversible | 5 min |
| 2 | Todoist desconectado | El «hoy» no existe como sistema | 30 min + token |
| 3 | 41 archivos sin descorruptar | 37% de lo recuperado sigue ilegible | 1 h |
| 4 | PIPELINE con 1 fila de prueba | Entregas no llegan a Notion | 1 h + datos reales |
| 5 | MONITOR parado 13 días | Marca un peligro de hace 2 semanas | 10 min/día |
| 6 | 3 tokens pasaron por chat o código | Superficie de fuga | 15 min |

## 3. Secuencia recomendada
1. `git init` y `.gitignore` en la bóveda. Sin esto, todo lo demás es frágil.
2. Rotar los 3 tokens.
3. Descorruptar los 41 y decidir por lotes.
4. Conectar Todoist de una sola dirección.
5. Cerrar PIPELINE con entregas reales.
6. SIM Fases 3 y 4.

## 4. Regla de oro
Notion para gestionar. Obsidian para pensar. Todoist para ejecutar hoy.
Nada suelto: cada dato tiene su lugar.

## 5. Honestidad del documento
Este plan no inventa capacidades. Los 6 cuellos son observados, no supuestos.
Lo único teórico es el puente con Todoist, y está marcado como tal en
`EGG_TODOIST_BRIDGE_REPORT.md`.
