<!-- E-100 V2 | datos verificados vía Notion REST API el 2026-10-04 | fuente: 90 SISTEMA/E100_V2/ | sin datos inventados -->

# EGG_TODOIST_BRIDGE_REPORT — Notion ↔ Todoist

## 1. Advertencia de veracidad
**Este informe es el menos verificado de los 11.**
La API de Todoist **no fue consultada**. No hay token de Todoist disponible en
el entorno. Todo lo que sigue es inferencia desde Notion, no dato.

## 2. Lo que se necesita desde Todoist
Para cerrar este informe hacen falta 3 consultas y ninguna se ha hecho:
1. Lista de proyectos activos y su estado.
2. Tareas de hoy y su filtro.
3. Mapa de etiquetas (`universidad`, `proyecto`, `area`).

## 3. Punto de anclaje en Notion
Las bases con fecha o estado propio que deberían espejar tareas:

| Base | Campo natural |
|---|---|
| PIPELINE DE ENTREGABLES | Fecha Limite |
| MONITOR DE INTEGRIDAD | Fecha |
| PROYECTO C1 | Estado + Progreso % |
| LOGÍSTICA FINANCIERA | Mes |

## 4. Estado actual de la integración
- MCP de Todoist: **desactivado** en la configuración de OpenCode (recorte MCP).
- Sin token en variables de entorno.
- Sin scripts de sincronización.
- Conclusión: la trinidad Notion + Obsidian + Todoist **no está conectada**.

## 5. Recomendaciones (requieren token)
1. Restaurar el MCP de Todoist en `opencode.json`.
2. Definir el contrato: qué base de Notion refleja qué vista de Todoist.
3. Empezar por una sola dirección: Notion como lectura, Todoist como escritura.
   Nunca bidireccional a la vez: genera ciclos.

## 6. Acción bloqueante
**Falta el token de Todoist.** Todo lo demás de este informe es teoría.
