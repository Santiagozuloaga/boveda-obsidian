<!-- E-100 V2 | datos verificados vía Notion REST API el 2026-10-04 | fuente: 90 SISTEMA/E100_V2/ | sin datos inventados -->

# E100_RECOVERY_PROTOCOL

## 1. Regla
Nada entra en la bóveda sin estar limpio y revisado. Lo dudoso va a staging.

## 2. Rutas
| Ruta | Qué es |
|---|---|
| `C:\Temp\STAGING_20261004\` | staging de todo el trabajo de recuperación |
| `...\recuperadas\` | 111 `.md` dudosos extraídos de la bóveda |
| `...\hashes\` | manifiestos, snapshots, scripts y logs |
| `...\hashes\omniroute_backup\` | backup previo al reset de OmniRoute |

## 3. Pipeline
1. **Staging**: extraer a `imports\<fuente>-<fecha>\`. Nunca directo a la bóveda.
2. **Triage**: tabla de qué se conserva y qué se descarta. Por defecto se
   descarta: el minimalismo es la regla.
3. **Materializar**: una nota índice por lote. Solo lo excepcional merece
   nota atómica.
4. **Limpiar**: ZIP crudo a `backups\`, borrar staging, reportar.

## 4. Estado actual
| Etapa | Cantidad |
|---|---|
| Movidos a staging | 111 |
| Descorruptos | 65 |
| Ya estaban limpios | 5 |
| **Pendientes** | **41** |

Los 41 están listados en `hashes/recup_raros.txt` y ordenados por lotes en
`hashes/recup_indice_lotes.md`.

## 5. Filtros intocables
- `05_PROTOCOLOS_Y_SISTEMAS/01_Constitucion_SOP/00_ARCHIVO_HISTORICO`: historia, no se toca.
- Tokens, API keys y `opencode.json`: solo lectura sin orden directa.
- Archivos abiertos en Obsidian en ese momento.

## 6. Debilidad actual
**No hay `git init` en la bóveda.** El snapshot de Notion es un JSON suelto.
Sin control de versiones, un error de escritura no se puede deshacer.
Es el paso que más riesgo reduce ahora mismo.
