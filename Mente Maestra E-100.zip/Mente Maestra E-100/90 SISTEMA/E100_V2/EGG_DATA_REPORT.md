<!-- E-100 V2 | datos verificados vía Notion REST API el 2026-10-04 | fuente: 90 SISTEMA/E100_V2/ | sin datos inventados -->

# EGG_DATA_REPORT — Estado de las bases

## 1. Inventario verificado
| Base | Props | Filas | Estado |
|---|---|---|---|
| CENTRAL ACADÉMICA | 15 | 5 | Funcional, con huecos |
| Active Recall (AR) | 7 | 6 | Funcional |
| PROYECTO C1 | 7 | 9 | 1 objetivo + 8 KR |
| PIPELINE DE ENTREGABLES | 8 | 1 | **Insuficiente** |
| MONITOR DE INTEGRIDAD | 13 | 1 | **Parado** |
| LOGÍSTICA FINANCIERA | 11 | 1 | **Incompleto** |

## 2. CENTRAL ACADÉMICA — 5 filas
| Materia | Nivel | Completadas/Total | Barra |
|---|---|---|---|
| Programacion | III | 6/8 | 75% |
| Geografia | II | 3/10 | 30% |
| Matematicas | I | sin datos | 0% |
| Quimica | I | sin datos | 0% |
| Fisica | I | sin datos | 0% |

3 de 5 materias tienen `Total` y `Completadas` vacíos. Sin esos números el
porcentaje y la barra mienten: dicen 0% cuando en realidad se desconoce.

## 3. PROYECTO C1 — 9 filas
8 Key Results con `Estado` = `Pendiente`:
B2 (Avanzado), B1 (Intermedio), A2 (Elemental), Relativsätze, Passiv,
Konjunktiv II, Dativ, Akkusativ.
+ 1 fila **sin título** (`3dcb38a4-c0ce-81c3-...`), no se modificó.
Todos los `Progreso %` estaban vacíos; se rellenaron a 0 (ver trazabilidad).

## 4. PIPELINE — el problema real
Única fila: `Parcial de Cálculo (prueba)`, Estado `ENTREGADO`, nota 4.5,
ponderada 0.9, peso 20%.
Pero CENTRAL declara **8 entregas en Programacion** y **10 en Geografia**.
El pipeline no refleja la realidad de la uni. O se migran las entregas reales,
o se acepta que el pipeline es un experimento abandonado.

## 5. MONITOR — parado
Única fila: `2026-09-19 Demo`. Estado: «PELIGRO CRÍTICO».
Cumplimiento 0.71, Barra 4/5, Racha 5.
Campos `Energía`, `Horas de Sueño`, `Vector de Ataque Externo` y
`Traducción Shard` vacíos.
**13 días de retraso** respecto a la fecha de esta auditoría.

## 6. LOGÍSTICA — incompleto
Única fila `Septiembre 2026`: Gastado 1200, Presupuesto 5000,
Ahorro Acumulado 5604, Restante 3800, Meta 11208.
Faltan las filas de **Octubre** y **Noviembre 2026**.
Campos `Ingreso`, `Progreso Sperrkonto`, `Gastos Universitarios` y `Notas` vacíos.

## 7. Campos vacíos por base
| Base | Campos con celdas vacías |
|---|---|
| CENTRAL | Profesor (5/5), Horario Tutorias (5/5), Estado (3/5), Total (3/5), Creditos (5/5), Nota Actual (5/5) |
| AR | Dificultad (3/6), Tipo (3/6), Proximo Repaso (3/6) |
| C1 | Progreso % (9/9), Fecha (9/9), Tipo (9/9), Notas (9/9) |
| PIPELINE | Tipo (1/1), Fecha Limite (1/1) |
| MONITOR | Energía, Vector, Estado, Sueño, Traducción (todas) |
| LOGÍSTICA | Ingreso, Progreso, Meta, Notas, Gastos Uni (todas) |

## 8. Nota metodológica
`Profesor`, `Horario Tutorias`, `Creditos` y `Nota Actual` están vacías en las 5
materias. No se rellenaron: son datos académicos que no se pueden derivar.
