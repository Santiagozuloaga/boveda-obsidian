<!-- E-100 V2 | datos verificados vía Notion REST API el 2026-10-04 | fuente: 90 SISTEMA/E100_V2/ | sin datos inventados -->

# E100_CHANGE_TRACEABILITY

## 1. Cambios aplicados en Notion (2026-10-04)
| # | Base | Fila | Campo | Valor | Origen del dato |
|---|---|---|---|---|---|
| 1 | CENTRAL | Programacion | Estado | En curso | 6/8 completadas |
| 2 | CENTRAL | Geografia | Estado | En curso | 3/10 completadas |
| 3 | C1 | B2 (Avanzado) | Progreso % | 0 | Estado = Pendiente |
| 4 | C1 | B1 (Intermedio) | Progreso % | 0 | Estado = Pendiente |
| 5 | C1 | A2 (Elemental) | Progreso % | 0 | Estado = Pendiente |
| 6 | C1 | Relativsätze | Progreso % | 0 | Estado = Pendiente |
| 7 | C1 | Passiv | Progreso % | 0 | Estado = Pendiente |
| 8 | C1 | Konjunktiv II | Progreso % | 0 | Estado = Pendiente |
| 9 | C1 | Dativ | Progreso % | 0 | Estado = Pendiente |
| 10 | C1 | Akkusativ | Progreso % | 0 | Estado = Pendiente |
| 11 | THE EGG-NETWORK | (página nueva) | 35 bloques | EGG V2 — AUDITORÍA SELECTIVA | informe de hoy |

**Total: 10 escrituras de datos + 1 creación. 0 borrados.**

## 2. No aplicado (y por qué)
| Acción | Motivo |
|---|---|
| `Total` y `Completadas` de Matematicas, Quimica y Fisica | No derivable: no hay dato |
| `Estado` de esas 3 materias | Depende del punto anterior |
| Fila sin título de C1 (`3dcb38a4`) | No se sabe qué representa |
| PIPELINE: migrar 17 entregas | Requiere notas y fechas reales |
| MONITOR: fila de hoy | Inventaría energía y sueño |
| LOGÍSTICA: filas de Oct y Nov | Requieren decisiones de presupuesto |
| Borrar `THE EGG-NETWORK prueba` | Irreversible vía API |
| `Profesor`, `Horario`, `Creditos`, `Nota Actual` | Datos académicos, no derivables |

## 3. Cambios en la bóveda
| Qué | Dónde |
|---|---|
| 11 informes V2 regenerados | `90 SISTEMA/E100_V2/` |
| 111 archivos dudosos | `C:\Temp\STAGING_20261004\recuperadas\` (fuera de la bóveda) |
| Snapshot de Notion | `hashes/notion_pre_selectivo.json` |
| Log de escrituras | `hashes/notion_pre_selectivo_aplicado.json` |

## 4. Rollback
Cada fila de la tabla 1 tiene su valor previo en el snapshot. El campo
`Estado` se puede devolver a `null` con un PATCH por `page_id`.
