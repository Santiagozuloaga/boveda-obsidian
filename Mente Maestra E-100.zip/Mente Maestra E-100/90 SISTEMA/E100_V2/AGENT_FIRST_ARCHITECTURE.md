<!-- E-100 V2 | datos verificados vía Notion REST API el 2026-10-04 | fuente: 90 SISTEMA/E100_V2/ | sin datos inventados -->

# AGENT_FIRST_ARCHITECTURE

## 1. Principio
La bóveda es la fuente de verdad. Notion y Todoist son vistas. Ningún agente
escribe en la bóveda sin snapshot.

## 2. Reglas que ya se aplican
1. **Lectura primero**: explorar antes de proponer.
2. **Escritura solo tras «sí» explícito**.
3. **Destructivo prohibido sin «sí» literal**: borrar requiere confirmación.
4. **Todo cambio reversible**: snapshot antes de escribir.
5. **Staging para lo dudoso**: `C:\Temp\STAGING_20261004\`, no la bóveda.

## 3. Verificado hoy
- Los 10 cambios en Notion se hicieron con snapshot previo y log de escritura.
- Los 111 archivos dudosos NO entraron a la bóveda: siguen en staging.
- El token de Notion se movió del código al registro antes de escribir.

## 4. Violaciones de este patrón detectadas (y corregidas)
| Violación | Dónde | Corrección |
|---|---|---|
| Token de Notion hardcodeado | `temp_rec/notion_pull.py`, `notion_audit.py` | movido a `HKCU\Environment\NOTION_TOKEN` |
| Informes con datos sin fuente | 11 informes V2 | regenerados con datos de API |

## 5. Pendiente de este patrón
- `git init` en la bóveda: sin él, un snapshot es un archivo suelto.
- Rotar los 3 tokens que han pasado por chat o por código.
