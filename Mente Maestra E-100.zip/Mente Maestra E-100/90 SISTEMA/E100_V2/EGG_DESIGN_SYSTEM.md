<!-- E-100 V2 | datos verificados vía Notion REST API el 2026-10-04 | fuente: 90 SISTEMA/E100_V2/ | sin datos inventados -->

# EGG_DESIGN_SYSTEM

## 1. Tokens observados
| Elemento | Convención |
|---|---|
| Prefijo de base | Emoji + nombre en mayúsculas (`AR`, `C1`, `PIPELINE`) |
| Prefijo de base largo | Emoji + descriptor (`MONITOR DE INTEGRIDAD 2.0`) |
| Página | EMOJI + TÍTULO EN MAYÚSCULAS |
| Nombre de fila | español, sin tildes en base de datos (`Programacion`, `Geografia`) |
| Fase o tag | `F1..Fn` con guion y paréntesis (`01_GRAMATICA (12.md)`) |
| Prefijo temporal | `AAAA-MM-DD_` |

## 2. Inconsistencias detectadas
1. Las **bases** usan emoji, las **filas** no. No hay convención para filas.
2. `Programacion` y `Geografia` sin tilde: rompen la búsqueda por acento.
3. `Minimalist Project Manager (1)`: sufijo numérico de creación automática.
4. La versión del Dashboard (V. 5.2) no coincide con la bóveda (V. 5.3).

## 3. Propuesta (no aplicada)
- Nombres de fila con las tildes correctas.
- Sufijo numérico solo en borradores, nunca en entregables.
- Versión del sistema en un único lugar: la bóveda es la canónica.

## 4. Criterio
No se renombró nada. Renombrar en Notion rompe relaciones existentes y las
notas ya escritas usan los nombres actuales.
